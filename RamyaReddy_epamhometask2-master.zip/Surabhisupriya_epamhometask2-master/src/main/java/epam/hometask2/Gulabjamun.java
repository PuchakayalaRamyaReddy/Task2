package epam.hometask2;

public class Gulabjamun extends Sweets {

	
	public int calcwt(int quantity,int weight)
	{
		return quantity*weight;
	}
}
