package epam.hometask2;

public abstract class Sweets {
     
    public abstract int calcwt(int quantity,int weight);
   
	
}
