package epam.hometask2;

public class Rasgulla extends Sweets{
	
	public int calcwt(int quantity,int weight)
	{
		return quantity*weight;
	}

}
